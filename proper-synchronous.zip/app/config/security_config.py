﻿"""
Global security guardrails for Cloud Security Panel.
"""

# Default execution mode
DEFAULT_EXECUTION_MODE = "DRY_RUN"

# LIVE execution requires BOTH to be true:
LIVE_EXECUTION_ENABLED = True
LIVE_EXECUTION_APPROVED_BY_USER = True

ALLOWED_LIVE_ACTIONS = {
    "ENABLE_S3_VERSIONING",
    "ENABLE_BLOCK_PUBLIC_ACCESS",
    "REMOVE_PUBLIC_S3_ACL",
    "DETACH_ADMIN_POLICY",
    "REMOVE_INLINE_POLICY",
    "RESTRICT_SECURITY_GROUP",
    "ENABLE_S3_ACCESS_LOGGING",
    "ENABLE_MFA",
    "DISABLE_ACCESS_KEY",
    "DELETE_ACCESS_KEY",
    "ENABLE_KMS_KEY_ROTATION",
    "ENABLE_VPC_FLOW_LOGS",
    "DELETE_UNUSED_SECURITY_GROUP",
    "REMOVE_INLINE_WILDCARD_POLICY",
    "RESTRICT_NACL_INBOUND",
    "RESTRICT_NACL_OUTBOUND",
    "REMOVE_PUBLIC_ROUTE",
    "RESTRICT_ROLE_EXTERNAL_TRUST",
    "ENABLE_CLOUDTRAIL",
    "START_CLOUDTRAIL_LOGGING",
    "ENABLE_TERMINATION_PROTECTION",
    "ENCRYPT_EBS_VOLUME",
    "ATTACH_IAM_ROLE_TO_INSTANCE",
    "REPLACE_SECURITY_GROUP",
    "REMOVE_ELASTIC_IP",
    "ENCRYPT_RDS_INSTANCE",
    "DELETE_UNUSED_IAM_USER"
}
# -----------------------------------
# 🔥 ADD THIS BLOCK (NEW)
# -----------------------------------
# S3_LOGGING_BUCKET = "mylogbucketrust"

# --------------------------------------------------
# Severity Mapping for all scanner findings
# --------------------------------------------------

SEVERITY_MAP = {

    # Firewall
    "PUBLIC_SECURITY_GROUP": "HIGH",

    # S3
    "PUBLIC_S3_BUCKET": "CRITICAL",
    "S3_BLOCK_PUBLIC_ACCESS_DISABLED": "HIGH",
    "S3_NO_ENCRYPTION": "HIGH",
    "S3_VERSIONING_DISABLED": "MEDIUM",
    "S3_ACCESS_LOGGING_DISABLED": "MEDIUM",

   # EC2
    "PUBLIC_EC2_INSTANCE": "HIGH",
    "EC2_WITHOUT_IAM_ROLE": "MEDIUM",
    "EC2_DEFAULT_SECURITY_GROUP": "MEDIUM",
    "EC2_TERMINATION_PROTECTION_DISABLED": "MEDIUM",
    "EBS_UNENCRYPTED_VOLUME": "HIGH",
    "EC2_PUBLIC_ELASTIC_IP": "HIGH",

    # Encryption
    "EBS_DEFAULT_ENCRYPTION_DISABLED": "HIGH",
    "S3_BUCKET_ENCRYPTION_DISABLED": "HIGH",
    "KMS_KEY_ROTATION_DISABLED": "MEDIUM",
    "EBS_SNAPSHOT_NOT_ENCRYPTED": "HIGH",
    "RDS_STORAGE_NOT_ENCRYPTED": "HIGH",


    # IAM
    "IAM_PASSWORD_NEVER_EXPIRES": "MEDIUM",
    "IAM_PASSWORD_POLICY_MISSING": "HIGH",
    "IAM_ADMIN_USER": "CRITICAL",
    "IAM_POLICY_FULL_ADMIN": "CRITICAL",
    "IAM_USER_WITHOUT_MFA": "HIGH",
    "IAM_ACCESS_KEY_OLD": "HIGH",
    "IAM_ACCESS_KEY_UNUSED": "MEDIUM",
    "IAM_MULTIPLE_ACCESS_KEYS": "HIGH",
    "IAM_WILDCARD_POLICY": "MEDIUM",
    "IAM_UNUSED_USER": "HIGH",
    "REMOVE_INLINE_POLICY": "CRITICAL",
    "IAM_INLINE_ADMIN_POLICY": "HIGH",
    "REMOVE_INLINE_WILDCARD_POLICY": "HIGH",
    "IAM_ROLE_ADMIN_POLICY": "CRITICAL",
    "IAM_ROLE_EXTERNAL_TRUST": "CRITICAL",
    "IAM_ACCESS_KEY_OLD_INACTIVE": "MEDIUM",


    # Logging
    "CLOUDTRAIL_DISABLED": "HIGH",
    "VPC_FLOW_LOGS_DISABLED": "MEDIUM",
    "CLOUDTRAIL_NOT_LOGGING": "HIGH",

    # Network
    "PUBLIC_SUBNET_DETECTED": "MEDIUM",
    "ROUTE_TABLE_PUBLIC_ROUTE": "MEDIUM",
    "NACL_ALLOW_ALL_INBOUND": "HIGH",
    "NACL_ALLOW_ALL_OUTBOUND": "MEDIUM",
    "INTERNET_GATEWAY_ATTACHED": "LOW",
    "UNUSED_SECURITY_GROUP": "MEDIUM",
    "VPC_WITHOUT_NAT_GATEWAY": "LOW",


}

# --------------------------------------------------
# Severity → Enforcement rules
# --------------------------------------------------

ENFORCEMENT_MAP = {
    "CRITICAL": "AUTO_FIX",
    "HIGH": "AUTO_FIX",
    "MEDIUM": "REQUIRE_APPROVAL",
    "LOW": "IGNORE",
    "INFO": "IGNORE"
}

# --------------------------------------------------
# Risk scoring weights
# --------------------------------------------------

RISK_WEIGHTS = {
    "CRITICAL": 10,
    "HIGH": 7,
    "MEDIUM": 4,
    "LOW": 2,
    "INFO": 1
}